---
title: Fault Finding
weight: 160
---

# Fault Finding

An online version of this will be introduced in due course. In the meantime, see the guidance on the Central Council website [here](https://cccbr.org.uk/wp-content/uploads/2021/06/SM_CommonProblems_2021_v3_1.pdf).

----

Version 0.1 (temporary), February 2022

© 2022 Central Council of Church Bell Ringers