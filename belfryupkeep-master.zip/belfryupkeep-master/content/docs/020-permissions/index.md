---
title: Formal Requirements
weight: 20
---

# Formal Requirements

This is a stub 

This section will cover permissions to work in general, Such as:

-   The role of the PCC (within CofE), incorporating the *Who Owns the Bells?* section in MBM Introduction chapter
-   Listed buildings, and Ecclesiactical Exemption
-   Archaeologically significant sites
-   Other relevant things?

There will also be sections covering towers in jurisdictions outside England, including towers owned privately and by municipialities. This will extend the role of the 'owner'.

The Faculty Jurisdiction Rules are covered [here](/docs/030-faculty-rules)



